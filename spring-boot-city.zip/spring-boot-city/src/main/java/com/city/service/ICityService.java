package com.city.service;
import java.util.List;

import com.city.bean.City;
public interface ICityService {

    public List<City> findAll();
}
