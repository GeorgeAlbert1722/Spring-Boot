package com.city;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCityApplication.class, args);
	}

}
