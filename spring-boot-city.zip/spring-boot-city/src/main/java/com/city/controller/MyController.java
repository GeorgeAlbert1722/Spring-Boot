package com.city.controller;

import com.city.bean.City;
import com.city.service.ICityService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@Autowired
	ICityService cityService;

	@RequestMapping(value = "/getCities")
	public List<City> getCities() {

		List<City> cities = cityService.findAll();

		return cities;
	}
}
