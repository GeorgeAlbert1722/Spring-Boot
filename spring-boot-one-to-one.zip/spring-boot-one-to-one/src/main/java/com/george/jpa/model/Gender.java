package com.george.jpa.model;

public enum Gender {
    MALE,
    FEMALE
}
